package com.example.demo.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entities.Student;
import com.example.demo.Services.StudentService;

@RestController
public class StudentController {
	
	StudentService studentService;
	
	
	@PostMapping("/addStudent")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<Student> saveNewStudent(@RequestBody Student student){
		Student addedStudent=this.studentService.addNewStudent(student);
		return new ResponseEntity<Student>(addedStudent,HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllStudtents")
	public ResponseEntity<List<Student>> getAllStudents(){
		List<Student> students=this.studentService.getAllStudents();
		return new ResponseEntity<List<Student>>(students,HttpStatus.OK);
	}
	
	@GetMapping("/getStudentById/{studentId}")
	public ResponseEntity<Student> getStudentById(@PathVariable(name="studentId") int studentId){
		Student student=this.studentService.getStudent(studentId);
		return new ResponseEntity<Student>(student,HttpStatus.OK);
	}

}
