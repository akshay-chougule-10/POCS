package com.example.demo.Services;

import java.util.List;

import com.example.demo.Entities.Student;

public interface StudentService {
	
	public Student addNewStudent(Student student);
	
	public List<Student> getAllStudents();
	
	public Student getStudent(int studentId);
	

}
