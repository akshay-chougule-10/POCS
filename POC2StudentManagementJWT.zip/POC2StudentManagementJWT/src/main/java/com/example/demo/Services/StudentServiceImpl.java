package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.StudentRepo;
import com.example.demo.Entities.Student;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepo studentRepo;
	
	@Override
	public Student addNewStudent(Student student) {
		this.studentRepo.save(student);
		return null;
	}

	@Override
	public List<Student> getAllStudents() {
		List<Student> studentList=this.studentRepo.findAll();
		return studentList;
	}

	@Override
	public Student getStudent(int studentId) {
		Student foundStudent=this.studentRepo.findById(studentId).orElse(null);
		return foundStudent;
	}

}
