package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poc2StudentManagementJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(Poc2StudentManagementJwtApplication.class, args);
	}

}
