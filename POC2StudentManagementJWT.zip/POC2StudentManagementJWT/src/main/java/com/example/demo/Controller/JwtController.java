package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entities.JWTRequest;
import com.example.demo.Services.Poc2UserDetailsService;
import com.example.demo.Services.StudentService;
import com.example.demo.jwt.helper.JwtResponse;
import com.example.demo.jwt.helper.JwtUtil;

@RestController
public class JwtController {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	JWTRequest jwtRequest;
	
	@Autowired
	StudentService studentService;
	
	@Autowired
	Poc2UserDetailsService poc2UserDetailsService;
	
	@Autowired
	private JwtUtil jwtUtil;

	@PostMapping("/token")
	public ResponseEntity<JwtResponse> genearateToken (@RequestBody JWTRequest jwtReq)throws Exception
	{
		
		try {
			
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtReq.getUsername(), jwtReq.getPassword()));
			
			
		}catch (UsernameNotFoundException e) {
			e.printStackTrace();
			throw new Exception("Bad credentials");
		}
		
		UserDetails userDetails= this.poc2UserDetailsService.loadUserByUsername(jwtReq.getUsername());
		
		String token =this.jwtUtil.generateToken(userDetails);
		return new ResponseEntity<>(new JwtResponse(token),HttpStatus.OK);
	}
	
	

}
